


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import javax.net.ssl.*;
import java.util.HashMap;



/*
 * java -Djavax.net.ssl.keyStore=<filename1> -Djavax.net.ssl.keyStorePassword=<password1> -Djavax.net.ssl.trustStore=<filename2> -Djavax.net.ssl.trustStorePassword=<password2>  
     
     
     passwords: 123456
     
     
     vm args in args:
    -Djavax.net.ssl.keyStore=keys_ssl/server.keys \
	-Djavax.net.ssl.keyStorePassword=123456 \ 
	-Djavax.net.ssl.trustStore=keys_ssl/truststore \
	-Djavax.net.ssl.trustStorePassword=123456
 * 
 */


public class Server {

	//                   plate nr, owner
	private static HashMap<String, String> Plates = new HashMap<String, String>();

	public static void main(String[] args) {
		int port_srv;


		if( args.length < 1){
			System.out.println("Wrong njumber of args");
			return;
		}

		port_srv = Integer.parseInt(args[0]);


		//ServerSocket sSocket = null;
		
		SSLServerSocket sslServerSocket = null;
		SSLServerSocketFactory sslSocketFactory = null;
		
		try {
			sslSocketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
			sslServerSocket = (SSLServerSocket) sslSocketFactory.createServerSocket(port_srv);
			sslServerSocket.setNeedClientAuth(true);
			
			//sSocket = new ServerSocket( port_srv);


			while(true){
				Socket s = null;
				
				try {
					//s = sSocket.accept();
					s = sslServerSocket.accept();
					threquest(s);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					break;
				} 


			}
			//sSocket.close();
			sslServerSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}






	}

	private static void threquest(Socket server){
		Thread threquest = new Thread(){
			public void run() {
				try {

					DataInputStream input = new DataInputStream(server.getInputStream());

					String msg = new String(input.readUTF()) ;


					System.out.println("Received: " + msg);

					String result = processRequest(msg);

					DataOutputStream output = new DataOutputStream(server.getOutputStream());

					output.writeUTF(result);
					input.close();

					output.close();
					server.close();

					//						System.out.println("*********");
					//						System.out.println("Request packet: " + msgPacket.getAddress().toString());
					//						System.out.println(msg);


				} catch (IOException ex) {

					ex.printStackTrace();

				}
			};
		};

		threquest.start();

	}

	private static String processRequest(String req){

		String[] reqSub = req.trim().split(" ");
		String result = new String();

		if( reqSub[0].contains("lookup") ){
			if(Plates.containsKey(reqSub[1])){
				result = reqSub[1] + ", " + Plates.get(reqSub[1]);
				System.out.println(reqSub[0] + " " + reqSub[1] + " :: " + result);


			} else {
				result = "ERROR";
				System.out.println(reqSub[0] + " " + reqSub[1] + " :: " + result);

			}
		} else { //can only be register

			if(!Plates.containsKey(reqSub[1])){
				Plates.put(reqSub[1], reqSub[2]);
				result = reqSub[1] + ", " + reqSub[2];
				System.out.println(reqSub[0] + " " + reqSub[1] + 
						" " + reqSub[2] +" :: " + result);
			} else{
				result = "ERROR";
				System.out.println(reqSub[0] + " " + reqSub[1] + 
						" " + reqSub[2] +" :: " + result);
			}
		}



		//Simulate alot of work
		try {
			Thread.sleep(250);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

	}



}
