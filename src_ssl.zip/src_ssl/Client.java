

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Random;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;


/*
 * java -Djavax.net.ssl.keyStore=<filename1> -Djavax.net.ssl.keyStorePassword=<password1> \ 
     -Djavax.net.ssl.trustStore=<filename2> - Djavax.net.ssl.trustStorePassword=<password2>  
     
     
     passwords: 123456
     
     
     vm args in args:
    -Djavax.net.ssl.keyStore=keys_ssl/client.keys \
	-Djavax.net.ssl.keyStorePassword=123456 \ 
	-Djavax.net.ssl.trustStore=keys_ssl/truststore \
	-Djavax.net.ssl.trustStorePassword=123456
 * 
 */


public class Client {

	public static void main(String[] args) {

		String[] keys = {"key1", "key2","key3", "key4", "key21","key31", "key41", "key22","key32", "key42", "key23","key33", "key43", "key24","key34", "key44", "key25","key35", "key45", "key26","key36", "key46", "key27","key37", "key47"};
		String[] values = {"value1", "value2","value3", "value4", "value21","value31", "value41", "value22","value32", "value42", "value23","value33", "value43", "value24","value34", "value44", "value25","value35", "value45", "value26","value36", "value46", "value27","value37", "value47"};
		String[] command = {"register", "lookup"};

		String addr_inet;
		int port_inet;

		if( args.length < 2){
			System.out.println("Wrong number of args");
			return;
		}


		addr_inet = args[0];
		port_inet = Integer.parseInt(args[1]);

		// Create a buffer of bytes, which will be used to store
		// the incoming bytes containing the information from the server.
		// Since the message is small here, 256 bytes should be enough.
		// Create a new Multicast socket (that will allow other sockets/programs
		// to join it as well.

		Random rad =  new Random(System.currentTimeMillis());

		for(int i = 0; i < 1000 ; i++){

			Thread th = new Thread(){
				@Override
				public void run() {
					super.run();

					String req = new String();
					SSLSocket sslsock = null;
					SSLSocketFactory sfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();

					try{
						sslsock = (SSLSocket) sfactory.createSocket(addr_inet, port_inet);
							
							//Socket reqSocket = new Socket(addr_inet,port_inet)){

						//							System.out.println("enter request:");
						//							Scanner s = new Scanner(System.in);
						//							req = s.nextLine();


						req = command[rad.nextInt(command.length)] +" " + keys[rad.nextInt(keys.length)]
								+ " " + values[rad.nextInt(values.length)];

						//DataOutputStream output = new DataOutputStream(reqSocket.getOutputStream());
						DataOutputStream output = new DataOutputStream(sslsock.getOutputStream());
						

						output.writeUTF(req);
						System.out.println("sent request: " + req);

						//DataInputStream input = new DataInputStream(reqSocket.getInputStream());
						DataInputStream input = new DataInputStream(sslsock.getInputStream());
						
						String resp = input.readUTF();
						System.out.println("Response: " + req + " :: " + resp);

						output.close();

						input.close();


						//reqSocket.close();
						sslsock.close();


					} catch (IOException e) {
						e.printStackTrace();
					}

				}
			};
			
			th.start();


		}



	}


}


